                      
"""
live_dashboard.py  –  Raspberry Pi
=====================================
Serveste dashboard-ul HTML (cu Jinja2) + endpoint /api/live
care citeste din SQLite si returneaza date in timp real.

Utilizare:
  python3 live_dashboard.py [session_id]

Daca session_id e omis, foloseste automat ultima sesiune activa.
Port: 8080

Oprire: Ctrl+C
"""

import sqlite3
import json
import sys
import os
import math
import time
import threading
import numpy as np
from datetime import datetime, timedelta
from flask import Flask, render_template_string, jsonify, abort

                                               
               
                                               
DB_PATH    = "/home/pi/raw_sensor_data.db"
DASH_PATH  = os.path.join(os.path.dirname(os.path.abspath(__file__)), "dashboard.html")
PORT       = 8080
UPDATE_SEC = 2                                             
WINDOW_SEC = 60                                                      
PPG_ROWS   = 12                                                                                     
FS_PPG_DEFAULT = 12.5                                                                                    

app = Flask(__name__)

                                               
          
                                               
_forced_session = None                  

def get_active_session():
    """Returneaza session_id-ul activ: fortat din CLI sau ultima sesiune din DB."""
    if _forced_session:
        return _forced_session
    try:
        conn = sqlite3.connect(DB_PATH, timeout=3)
        row = conn.execute(
            "SELECT session_id FROM raw_data ORDER BY id DESC LIMIT 1"
        ).fetchone()
        conn.close()
        return row[0] if row else None
    except Exception:
        return None


                                               
                   
                                               
def auto_detect_fs(ppg_rows):
    """Detecteaza FS_PPG real din intervalele dintre blocuri si marimea blocului.
    Fallback la FS_PPG_DEFAULT (12.5Hz) daca nu are date suficiente."""
    if len(ppg_rows) < 3:
        return FS_PPG_DEFAULT
    try:
                                                       
        sizes = []
        for r in ppg_rows:
            s = r['ir_samples'] or ''
            sizes.append(len([v for v in s.split(',') if v.strip()]))
        block_size = float(np.median(sizes)) if sizes else 25.0
        if block_size < 2:
            return FS_PPG_DEFAULT

                                                    
        ts_list = []
        for r in ppg_rows:
            try:
                ts_list.append(datetime.strptime(r['pc_timestamp'], '%Y-%m-%d %H:%M:%S'))
            except Exception:
                pass
        if len(ts_list) < 3:
            return FS_PPG_DEFAULT
        intervals = [(ts_list[i+1]-ts_list[i]).total_seconds() for i in range(len(ts_list)-1)]
        median_interval = float(np.median(intervals))
        if median_interval <= 0:
            return FS_PPG_DEFAULT

        fs = block_size / median_interval
                                                               
        return float(np.clip(fs, 5.0, 100.0))
    except Exception:
        return FS_PPG_DEFAULT


def bandpass_ir(samples, fs=FS_PPG_DEFAULT, low=0.5, high=3.5):
    """Butterworth bandpass 0.5–3.5 Hz pe semnalul IR brut."""
    from scipy.signal import butter, filtfilt
    nyq = fs / 2.0
                                                                       
    high_clipped = min(high, nyq * 0.9)
    if low >= high_clipped:
        return samples                               
    b, a = butter(2, [low / nyq, high_clipped / nyq], btype='band')
    return filtfilt(b, a, samples)


def normalize_waveform(filtered):
    """Normalizeaza waveform-ul la [-1, 1] pentru display.
    Foloseste std-based scaling (robust la transientul initial DC).
    3*std acopera ~99.7% din semnal fara a fi dominat de spike-ul de start."""
    arr = np.array(filtered, dtype=float)
    std = float(np.std(arr))
    if std < 1e-6:
        return [0.0] * len(arr)
                                                                                
    normed = np.clip(arr / (1.5 * std), -1.0, 1.0)
    return [round(float(v), 4) for v in normed]


def detect_bpm(filtered, fs=FS_PPG_DEFAULT):
    """Detecteaza BPM din semnalul bandpass-filtrat.
    Returneaza (bpm, confidence) unde confidence e in [0,1]."""
    from scipy.signal import find_peaks
    arr = np.array(filtered, dtype=float)
    std = float(np.std(arr))
    if std < 1e-6:
        return 0, 0.0

                                                                                   
    min_dist   = max(int(0.5 * fs), 3)
    prominence = 0.4 * std                                                                       
    peaks, _   = find_peaks(arr, prominence=prominence, distance=min_dist)

    if len(peaks) < 2:
        return 0, 0.0

    intervals = np.diff(peaks) / fs                          
    bpm       = 60.0 / float(np.mean(intervals))
    bpm_int   = int(round(bpm))

    if not (40 <= bpm_int <= 120):
        return 0, 0.0

                                            
    cv         = float(np.std(intervals) / np.mean(intervals)) if np.mean(intervals) > 0 else 1.0
    confidence = round(max(0.0, min(1.0, 1.0 - cv * 2)), 2)

    return bpm_int, confidence


def parse_samples_str(s, dtype=float):
    """Parseaza string CSV de samples in lista Python."""
    if not s:
        return []
    try:
        return [dtype(v) for v in s.split(',') if v.strip()]
    except Exception:
        return []


                                               
            
                                               
def build_live_payload(session_id):
    """Construieste JSON-ul complet pentru /api/live dintr-o sesiune."""
    now    = datetime.now()
    cutoff = (now - timedelta(seconds=WINDOW_SEC)).strftime('%Y-%m-%d %H:%M:%S')

    conn = sqlite3.connect(DB_PATH, timeout=5)
    conn.row_factory = sqlite3.Row

                                                                       
    raw_rows = conn.execute("""
        SELECT pc_timestamp, acc_x, acc_y, acc_z,
               gyro_x, gyro_y, gyro_z,
               temp_c, pressure_hpa
        FROM raw_data
        WHERE session_id = ? AND pc_timestamp >= ?
        ORDER BY pc_timestamp ASC
    """, (session_id, cutoff)).fetchall()

    time_labels = [r['pc_timestamp'][-8:] for r in raw_rows]
    acc_x   = [round(r['acc_x']  or 0.0, 4) for r in raw_rows]
    acc_y   = [round(r['acc_y']  or 0.0, 4) for r in raw_rows]
    acc_z   = [round(r['acc_z']  or 0.0, 4) for r in raw_rows]
    gyro_x  = [round(r['gyro_x'] or 0.0, 3) for r in raw_rows]
    gyro_y  = [round(r['gyro_y'] or 0.0, 3) for r in raw_rows]
    gyro_z  = [round(r['gyro_z'] or 0.0, 3) for r in raw_rows]
    acc_mag = [round(math.sqrt(x**2+y**2+z**2), 4) for x,y,z in zip(acc_x, acc_y, acc_z)]
    temp_c  = [round(r['temp_c'] or 0.0, 2) for r in raw_rows]

    n_samples     = len(raw_rows)
    last_temp     = round(float(raw_rows[-1]['temp_c']),    2) if raw_rows else None
    last_pressure = round(float(raw_rows[-1]['pressure_hpa']), 2) if raw_rows else None

                                                                       
    ppg_rows = conn.execute("""
        SELECT id, pc_timestamp, ir_samples, red_samples
        FROM ppg_data
        WHERE session_id = ?
        ORDER BY id DESC LIMIT ?
    """, (session_id, PPG_ROWS)).fetchall()
    ppg_rows = list(reversed(ppg_rows))

                                          
    fs_ppg = auto_detect_fs(ppg_rows)

    ir_all = []
    for pr in ppg_rows:
        ir_all.extend(parse_samples_str(pr['ir_samples'], int))

    bpm_estimate  = 0
    bpm_confidence= 0.0
    ppg_waveform  = []
    contact_quality  = 'none'
    contact_message  = 'Senzor deconectat'
    ppg_block_age_sec = None
    ppg_valid     = 0
    last_ir       = ir_all[-1] if ir_all else 0

                                      
    if last_ir > 80000:
        contact_quality = 'strong'
        contact_message = 'Contact ferm'
        ppg_valid = 1
    elif last_ir > 30000:
        contact_quality = 'weak'
        contact_message = 'Contact slab — apasa senzorul'
        ppg_valid = 1
    else:
        contact_quality = 'none'
        contact_message = 'Senzor deconectat / fara deget'
        ppg_valid = 0

                                 
    if ppg_rows:
        try:
            last_ts = ppg_rows[-1]['pc_timestamp']
            last_dt = datetime.strptime(last_ts, '%Y-%m-%d %H:%M:%S')
            ppg_block_age_sec = round((now - last_dt).total_seconds(), 1)
        except Exception:
            pass


                                                                         
    bpm_stale = (ppg_block_age_sec is not None and ppg_block_age_sec > 30)

                                                                                               
    MIN_SAMPLES = max(int(fs_ppg * 2), 20)
    if ppg_valid and len(ir_all) >= MIN_SAMPLES:
        try:
            filtered = bandpass_ir(np.array(ir_all, dtype=float), fs=fs_ppg)
            skip = min(int(fs_ppg * 3), len(filtered) // 2)
            steady = filtered[skip:]
            if len(steady) >= 10:
                bpm_estimate, bpm_confidence = detect_bpm(steady, fs=fs_ppg)
                display_seg = steady[-80:] if len(steady) >= 80 else steady
                ppg_waveform = normalize_waveform(display_seg)
        except Exception as e:
            print(f"[PPG] eroare (fs={fs_ppg:.1f}Hz, n={len(ir_all)}): {e}")
            ppg_waveform = []
        try:
            filtered = bandpass_ir(np.array(ir_all, dtype=float), fs=fs_ppg)
            skip = min(int(fs_ppg * 3), len(filtered) // 2)
            steady = filtered[skip:]
            if len(steady) >= 10:
                bpm_estimate, bpm_confidence = detect_bpm(steady, fs=fs_ppg)
                display_seg = steady[-80:] if len(steady) >= 80 else steady
                ppg_waveform = normalize_waveform(display_seg)
        except Exception as e:
            print(f"[PPG] eroare procesare (fs={fs_ppg:.1f}Hz, n={len(ir_all)}): {e}")
            ppg_waveform = []                                    

                                                                        
                                                                      
                                                                                    
    flex_rows = conn.execute("""
        SELECT fd_samples, pc_timestamp
        FROM flex_data
        WHERE session_id = ?
        ORDER BY id DESC LIMIT 60
    """, (session_id,)).fetchall()
    flex_rows = list(reversed(flex_rows))               

    flex_delta = []
    for fr in flex_rows:
        flex_delta.extend(parse_samples_str(fr['fd_samples'], float))

                                                                
                                                          
    max_flex_samples = WINDOW_SEC * 4                            
    if len(flex_delta) > max_flex_samples:
        flex_delta = flex_delta[-max_flex_samples:]

                                                                   
    if not flex_delta:
        flex_delta_raw = conn.execute("""
            SELECT flex_delta FROM raw_data
            WHERE session_id = ? AND pc_timestamp >= ?
            ORDER BY pc_timestamp ASC
        """, (session_id, cutoff)).fetchall()
        flex_delta = [r['flex_delta'] or 0.0 for r in flex_delta_raw]

                                                                              
    if flex_delta:
        recent = flex_delta[-4:]
        last_flex = round(float(np.mean(recent)), 1)
    else:
        last_flex = None

                                                                 
                                                                      
    n_labels = len(time_labels)
    if n_labels > 0 and len(flex_delta) > 0:
        fs_flex = 4
                                                                             
        step = max(1, len(flex_delta) // n_labels)
                                                                     
        ds = []
        for i in range(n_labels):
            start = i * step
            end   = min(start + step, len(flex_delta))
            chunk = flex_delta[start:end]
            ds.append(round(float(np.mean(chunk)), 2) if chunk else 0.0)
        flex_delta = ds
    else:
        flex_delta = [0.0] * n_labels

                                                                       
    mic_row = conn.execute("""
        SELECT samples FROM mic_data
        WHERE session_id = ?
        ORDER BY id DESC LIMIT 1
    """, (session_id,)).fetchone()

    mic_rms = 0.0
    if mic_row:
        try:
            samps = np.array(parse_samples_str(mic_row['samples'], int), dtype=float)
            if len(samps) > 0:
                mean_dc = float(np.mean(samps))
                mic_rms = round(float(np.sqrt(np.mean((samps - mean_dc) ** 2))), 1)
        except Exception:
            pass

    conn.close()

    return {
        "session_id":        session_id,
        "last_update":       now.strftime('%Y-%m-%d %H:%M:%S'),

                   
        "bpm_estimate":      bpm_estimate,
        "bpm_confidence":    bpm_confidence,
        "bpm_stale":         bpm_stale,
        "contact_quality":   contact_quality,
        "contact_message":   contact_message,
        "ppg_valid":         ppg_valid,
        "last_ir":           int(last_ir),
        "ppg_waveform":      ppg_waveform,
        "ppg_block_age_sec": ppg_block_age_sec,

                
        "last_temp":         last_temp,
        "last_flex":         last_flex,
        "last_pressure":     last_pressure,
        "mic_rms":           mic_rms,
        "n_samples":         n_samples,

                      
        "time_labels":       time_labels,
        "acc_x":             acc_x,
        "acc_y":             acc_y,
        "acc_z":             acc_z,
        "acc_mag":           acc_mag,
        "gyro_x":            gyro_x,
        "gyro_y":            gyro_y,
        "gyro_z":            gyro_z,
        "flex_delta":        flex_delta,
        "temp_c":            temp_c,
    }


                                               
         
                                               
@app.route('/')
def index():
    """Serveste dashboard-ul HTML cu variabilele Jinja2 completate."""
    try:
        with open(DASH_PATH, 'r', encoding='utf-8') as f:
            template = f.read()
        return render_template_string(
            template,
            update_sec=UPDATE_SEC,
            window_sec=WINDOW_SEC,
        )
    except FileNotFoundError:
        abort(404, f"dashboard.html not found at {DASH_PATH}")


@app.route('/api/live')
def api_live():
    """Returneaza date live din SQLite pentru sesiunea activa."""
    session_id = get_active_session()
    if not session_id:
        return jsonify({"error": "No active session in database"}), 503
    try:
        payload = build_live_payload(session_id)
        return jsonify(payload)
    except Exception as e:
        print(f"[API] eroare build_live_payload: {e}")
        import traceback; traceback.print_exc()
                                                        
                                                              
        return jsonify({
            "session_id":      session_id,
            "last_update":     datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            "bpm_estimate":    0, "bpm_confidence": 0, "bpm_stale": True,
            "contact_quality": "none", "contact_message": f"Server error: {e}",
            "ppg_valid": 0, "last_ir": 0, "ppg_waveform": [],
            "ppg_block_age_sec": None,
            "last_temp": None, "last_flex": None, "last_pressure": None,
            "mic_rms": 0, "n_samples": 0,
            "time_labels": [], "acc_x": [], "acc_y": [], "acc_z": [],
            "acc_mag": [], "gyro_x": [], "gyro_y": [], "gyro_z": [],
            "flex_delta": [], "temp_c": [],
        })


@app.route('/api/status')
def api_status():
    """Health check simplu."""
    session_id = get_active_session()
    return jsonify({
        "ok":        session_id is not None,
        "session_id": session_id,
        "time":      datetime.now().strftime('%H:%M:%S'),
    })


                                               
       
                                               
if __name__ == '__main__':
    if len(sys.argv) > 1:
        _forced_session = sys.argv[1]
        print(f"  Sesiune fortata: {_forced_session}")
    else:
        sid = get_active_session()
        print(f"  Sesiune auto-detectata: {sid or 'NICIUNA (DB gol?)'}")

    print(f"  Dashboard: http://YOUR_SERVER_IP:{PORT}")
    print(f"  API live:  http://YOUR_SERVER_IP:{PORT}/api/live")
    print(f"  Oprire:    Ctrl+C\n")

    app.run(host='0.0.0.0', port=PORT, debug=False, threaded=True)
