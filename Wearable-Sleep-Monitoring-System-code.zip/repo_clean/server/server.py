"""
server.py  –  Raspberry Pi
===========================
Server HTTP care primeste date de la ESP32 prin WiFi
si le salveaza in SQLite.

Utilizare:
  python3 server.py <subject_id> <nume>
  python3 server.py subject_01 Alexandru

Oprire:
  Ctrl+C  →  sesiunea se incheie si se salveaza
"""

import sqlite3
import json
import sys
import os
import signal
from datetime import datetime
from http.server import HTTPServer, BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs
import threading

                                               
               
                                               
DB_PATH  = "/home/pi/raw_sensor_data.db"
HOST     = "0.0.0.0"                                 
PORT     = 5000
                                               

                       
session_state = {
    "active":     False,
    "session_id": None,
    "subject_id": None,
    "name":       None,
    "start_time": None,
    "count_raw":  0,
    "count_mic":  0,
    "count_ppg":  0,
    "count_flex": 0,
}

def init_db():
    """Creeaza tabelele daca nu exista + activeaza WAL mode pentru concurenta cu dashboard."""
    conn = sqlite3.connect(DB_PATH)
                                                                                
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=NORMAL")                                
    conn.execute("""
        CREATE TABLE IF NOT EXISTS raw_data (
            id            INTEGER PRIMARY KEY AUTOINCREMENT,
            pc_timestamp  TEXT,
            sensor_time   TEXT,
            flex_raw      INTEGER,
            flex_delta    INTEGER,
            red           INTEGER,
            ir            INTEGER,
            acc_x         REAL,
            acc_y         REAL,
            acc_z         REAL,
            gyro_x        REAL,
            gyro_y        REAL,
            gyro_z        REAL,
            temp_c        REAL,
            pressure_hpa  REAL,
            subject_id    TEXT,
            session_id    TEXT,
            session_label TEXT
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS mic_data (
            id            INTEGER PRIMARY KEY AUTOINCREMENT,
            pc_timestamp  TEXT,
            sensor_time   TEXT,
            samples       TEXT,
            subject_id    TEXT,
            session_id    TEXT,
            session_label TEXT
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS ppg_data (
            id            INTEGER PRIMARY KEY AUTOINCREMENT,
            pc_timestamp  TEXT,
            sensor_time   TEXT,
            ir_samples    TEXT,
            red_samples   TEXT,
            subject_id    TEXT,
            session_id    TEXT,
            session_label TEXT
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS flex_data (
            id            INTEGER PRIMARY KEY AUTOINCREMENT,
            pc_timestamp  TEXT,
            sensor_time   TEXT,
            fr_samples    TEXT,
            fd_samples    TEXT,
            subject_id    TEXT,
            session_id    TEXT,
            session_label TEXT
        )
    """)
                                                                
    conn.execute("CREATE INDEX IF NOT EXISTS idx_raw_session_ts ON raw_data(session_id, pc_timestamp)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_ppg_session_ts ON ppg_data(session_id, pc_timestamp)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_mic_session_ts ON mic_data(session_id, pc_timestamp)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_flex_session_ts ON flex_data(session_id, pc_timestamp)")
    conn.commit()
    conn.close()


                                                                                          
_db_lock = threading.Lock()

def _db_write(sql, params):
    """Executa INSERT in DB cu lock thread-safe + retry pe 'database is locked'."""
    import time as _time
    for attempt in range(3):
        try:
            with _db_lock:
                conn = sqlite3.connect(DB_PATH, timeout=5)
                conn.execute(sql, params)
                conn.commit()
                conn.close()
            return
        except sqlite3.OperationalError as e:
            if "locked" in str(e).lower() and attempt < 2:
                _time.sleep(0.1 * (attempt + 1))
                continue
            raise


def insert_raw(data: dict):
    """Insereaza un rand in raw_data (thread-safe cu retry)."""
    _reset_timeout_timer()                                              
    _db_write("""
        INSERT INTO raw_data (
            pc_timestamp, sensor_time,
            flex_raw, flex_delta, red, ir,
            acc_x, acc_y, acc_z,
            gyro_x, gyro_y, gyro_z,
            temp_c, pressure_hpa,
            subject_id, session_id, session_label
        ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
    """, (
        datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        data.get("t", ""),
        data.get("fr", 0),
        data.get("fd", 0),
        data.get("red", 0),
        data.get("ir", 0),
        data.get("ax", 0.0),
        data.get("ay", 0.0),
        data.get("az", 0.0),
        data.get("gx", 0.0),
        data.get("gy", 0.0),
        data.get("gz", 0.0),
        data.get("tmp", 0.0),
        data.get("prs", 0.0),
        session_state["subject_id"],
        session_state["session_id"],
        session_state["session_id"],
    ))
    session_state["count_raw"] += 1


def insert_mic(data: dict):
    """Insereaza un bloc microfon in mic_data (thread-safe cu retry)."""
    _db_write("""
        INSERT INTO mic_data (
            pc_timestamp, sensor_time, samples,
            subject_id, session_id, session_label
        ) VALUES (?,?,?,?,?,?)
    """, (
        datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        data.get("t", ""),
        data.get("s", ""),
        session_state["subject_id"],
        session_state["session_id"],
        session_state["session_id"],
    ))
    session_state["count_mic"] += 1


def insert_ppg(data: dict):
    """Insereaza un bloc PPG (50 samples IR + 50 samples RED) in ppg_data (thread-safe cu retry)."""
    _db_write("""
        INSERT INTO ppg_data (
            pc_timestamp, sensor_time, ir_samples, red_samples,
            subject_id, session_id, session_label
        ) VALUES (?,?,?,?,?,?,?)
    """, (
        datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        data.get("t", ""),
        data.get("ir", ""),
        data.get("red", ""),
        session_state["subject_id"],
        session_state["session_id"],
        session_state["session_id"],
    ))
    session_state["count_ppg"] += 1


def insert_flex(data: dict):
    """Insereaza un bloc flex (samples raw + delta) in flex_data (thread-safe cu retry)."""
    _db_write("""
        INSERT INTO flex_data (
            pc_timestamp, sensor_time, fr_samples, fd_samples,
            subject_id, session_id, session_label
        ) VALUES (?,?,?,?,?,?,?)
    """, (
        datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        data.get("t", ""),
        data.get("fr_s", ""),
        data.get("fd_s", ""),
        session_state["subject_id"],
        session_state["session_id"],
        session_state["session_id"],
    ))
    session_state["count_flex"] += 1


                                               
               
                                               

                                               
import threading

DATA_TIMEOUT_SEC = 120                                
_last_data_time  = None
_timeout_timer   = None

def _reset_timeout_timer():
    global _timeout_timer, _last_data_time
    import time
    _last_data_time = time.time()
    if _timeout_timer:
        _timeout_timer.cancel()
    _timeout_timer = threading.Timer(DATA_TIMEOUT_SEC, _timeout_alert)
    _timeout_timer.daemon = True
    _timeout_timer.start()

def _timeout_alert():
    import time
    elapsed = int(time.time() - (_last_data_time or time.time()))
    print(f"\n[TIMEOUT] ATENTIE: Nu au venit date de {elapsed}s!")
    print(f"   Verifica daca ESP32 e pornit si conectat la WiFi.")
    print(f"   Ultima data primita: {datetime.fromtimestamp(_last_data_time).strftime('%H:%M:%S') if _last_data_time else 'N/A'}")
                                               
    global _timeout_timer
    _timeout_timer = threading.Timer(DATA_TIMEOUT_SEC, _timeout_alert)
    _timeout_timer.daemon = True
    _timeout_timer.start()


class SleepHandler(BaseHTTPRequestHandler):

    def log_message(self, format, *args):
        pass                                  

    def send_ok(self, msg="OK"):
        self.send_response(200)
        self.send_header("Content-Type", "text/plain")
        self.end_headers()
        self.wfile.write(msg.encode())

    def send_err(self, code, msg):
        self.send_response(code)
        self.send_header("Content-Type", "text/plain")
        self.end_headers()
        self.wfile.write(msg.encode())

    def do_GET(self):
        """
        GET /status  →  returneaza starea sesiunii (folosit de ESP pentru ping)
        """
        if self.path == "/status":
            status = {
                "active":     session_state["active"],
                "session_id": session_state["session_id"],
                "count_raw":  session_state["count_raw"],
                "count_ppg":  session_state["count_ppg"],
                "count_mic":  session_state["count_mic"],
            }
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(json.dumps(status).encode())
        else:
            self.send_err(404, "Not found")

    def do_POST(self):
        """
        POST /data   →  date senzori 1Hz (IMU + flex + temp + 1 sample PPG)
        POST /ppg    →  bloc PPG 50Hz (50 samples IR + RED, trimis la 1Hz)
        POST /mic    →  date microfon (JSON, ~1s la 200Hz)
        """
        if not session_state["active"]:
            self.send_err(503, "Session not active")
            return

        content_len = int(self.headers.get("Content-Length", 0))
        if content_len == 0:
            self.send_err(400, "Empty body")
            return

        try:
            body = self.rfile.read(content_len)
            data = json.loads(body.decode("utf-8"))
        except Exception as e:
            self.send_err(400, f"JSON error: {e}")
            return

        if self.path == "/data":
            insert_raw(data)
                                                                          
            if "ppg_ir" in data and "ppg_red" in data:
                insert_ppg({
                    "t":   data.get("t", ""),
                    "ir":  data["ppg_ir"],
                    "red": data["ppg_red"],
                })
                                         
            if "mic_s" in data:
                insert_mic({
                    "t": data.get("t", ""),
                    "s": data["mic_s"],
                })
                                                       
            if "fr_s" in data and "fd_s" in data:
                insert_flex({
                    "t":    data.get("t", ""),
                    "fr_s": data["fr_s"],
                    "fd_s": data["fd_s"],
                })
            if session_state["count_raw"] % 60 == 0:
                print(f"  [RAW] {session_state['count_raw']} randuri | "
                      f"PPG: {session_state['count_ppg']} blocuri | "
                      f"FLEX: {session_state['count_flex']} blocuri | "
                      f"MIC: {session_state['count_mic']} blocuri", flush=True)
            self.send_ok("OK")

        elif self.path == "/ppg":
            insert_ppg(data)
            self.send_ok("OK")

        elif self.path == "/mic":
            insert_mic(data)
            self.send_ok("OK")

        else:
            self.send_err(404, "Unknown endpoint")


                                               
       
                                               

def start_session(subject_id: str, name: str):
    """Porneste o sesiune noua de inregistrare."""
    now = datetime.now()
    session_id = f"{subject_id}_{now.strftime('%Y%m%d_%H%M%S')}"

    session_state["active"]     = True
    session_state["session_id"] = session_id
    session_state["subject_id"] = subject_id
    session_state["name"]       = name
    session_state["start_time"] = now
    session_state["count_raw"]  = 0
    session_state["count_mic"]  = 0
    session_state["count_ppg"]  = 0
    session_state["count_flex"] = 0

    print(f"\n{'='*55}")
    print(f"  SESIUNE PORNITA")
    print(f"  Subject ID : {subject_id}")
    print(f"  Nume       : {name}")
    print(f"  Session ID : {session_id}")
    print(f"  Ora start  : {now.strftime('%H:%M:%S')}")
    print(f"  Server     : http://YOUR_SERVER_IP:{PORT}")
    print(f"{'='*55}")
    print(f"\n  Asteapta conexiunea ESP32...")
    print(f"  Oprire: Ctrl+C\n")

    return session_id


def stop_session():
    """Opreste sesiunea si afiseaza rezumat."""
    session_state["active"] = False
    duration = datetime.now() - session_state["start_time"]
    minutes  = int(duration.total_seconds() / 60)

    print(f"\n\n{'='*55}")
    print(f"  SESIUNE OPRITA")
    print(f"  Session ID : {session_state['session_id']}")
    print(f"  Durata     : {minutes} minute")
    print(f"  Randuri raw: {session_state['count_raw']}")
    print(f"  Blocuri PPG: {session_state['count_ppg']}")
    print(f"  Blocuri FLEX: {session_state['count_flex']}")
    print(f"  Blocuri MIC: {session_state['count_mic']}")
    print(f"{'='*55}")
    print(f"\nPentru analiza ruleaza:")
    print(f"  python3 sleep_pipeline.py {session_state['session_id']}")
    print(f"  python3 advanced_analysis.py {session_state['session_id']}\n")


def main():
    if len(sys.argv) < 3:
        print("Utilizare: python3 server.py <subject_id> <nume>")
        print("Exemplu:   python3 server.py subject_01 Alexandru")
        sys.exit(1)

    subject_id = sys.argv[1]
    name       = " ".join(sys.argv[2:])

    init_db()
    start_session(subject_id, name)

                                                                                                         
    server = ThreadingHTTPServer((HOST, PORT), SleepHandler)

                             
    def handle_sigint(sig, frame):
        stop_session()
        server.shutdown()
        sys.exit(0)

    signal.signal(signal.SIGINT, handle_sigint)

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        stop_session()


if __name__ == "__main__":
    main()
