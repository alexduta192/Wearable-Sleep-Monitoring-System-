"""
advanced_analysis.py
====================
Module de analiza avansata pentru proiectul de monitorizare somn.
Adauga la sleep_pipeline.py:

1. Radar Chart       - toate componentele scorului vizualizate ca pentagon
2. HRV Spectral      - analiza LF/HF prin FFT pe intervalele RR
3. Trend Multi-Sesiune - evolutia scorului pe mai multe nopti
4. Random Forest vs KNN - comparatie algoritmi de clasificare
5. Heatmap Corelatii - matrix completa subiectiv vs obiectiv

Utilizare:
  python3 advanced_analysis.py <session_id>        # analiza completa
  python3 advanced_analysis.py trend               # doar trend multi-sesiune
  python3 advanced_analysis.py compare <session_id> # RF vs KNN
"""

import sqlite3
import numpy as np
import pandas as pd
import json
import os
import sys
import warnings
warnings.filterwarnings("ignore")

from scipy import signal
from scipy.fft import fft, fftfreq

from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.cluster import KMeans
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import cross_val_score, StratifiedKFold
from sklearn.metrics import (confusion_matrix, classification_report,
                             accuracy_score, silhouette_score)
from sklearn.decomposition import PCA

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import matplotlib.patches as mpatches
from matplotlib.patches import FancyArrowPatch
import matplotlib.colors as mcolors

                                     
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
try:
    from sleep_pipeline import (
        load_raw_data, load_mic_data, split_windows,
        extract_all_features, preprocess_features,
        run_kmeans, compute_sleep_score,
        DB_PATH, OUTPUT_DIR, WINDOW_SEC, N_CLUSTERS,
        STAGE_COLORS, FEATURE_COLS, FS_PPG, FS_IMU, bandpass_filter,
        load_ppg_data, expand_ppg_blocks, _ppg_50hz_df
    )
    DB_PATH = "/home/pi/raw_sensor_data.db"
except ImportError:
    print("EROARE: sleep_pipeline.py trebuie sa fie in acelasi director!")
    sys.exit(1)

os.makedirs(OUTPUT_DIR, exist_ok=True)

                                                                 
                                                     
                                                                 

def plot_radar_chart(score_result: dict, session_id: str):
    """
    Radar (spider) chart cu cele 6 componente ale scorului de somn.
    Fiecare axa = o componenta, normalizata la max posibil.
    """
    components = score_result.get("components", {})
    if not components:
        print("[RADAR] Nu exista componente de scor!")
        return

                                    
    max_values = {
        "architecture": 30,
        "ppg_quality":  20,
        "respiration":  20,
        "movement":     15,
        "hrv":          10,
        "snoring":       5,
    }

    labels = []
    values = []
    maxes  = []

    for key, max_val in max_values.items():
        if key in components:
            labels.append(key.replace("_", "\n").title())
            values.append(components[key])
            maxes.append(max_val)

                     
    values_norm = [v / m for v, m in zip(values, maxes)]

    N = len(labels)
    angles = np.linspace(0, 2 * np.pi, N, endpoint=False).tolist()

                       
    values_norm += values_norm[:1]
    angles      += angles[:1]

    fig, ax = plt.subplots(figsize=(8, 8), subplot_kw=dict(polar=True))
    fig.patch.set_facecolor("#0D1117")
    ax.set_facecolor("#0D1117")

          
    ax.set_xticks(angles[:-1])
    ax.set_xticklabels(labels, color="white", fontsize=10, fontweight="bold")
    ax.set_yticks([0.25, 0.5, 0.75, 1.0])
    ax.set_yticklabels(["25%", "50%", "75%", "100%"], color="gray", fontsize=7)
    ax.set_ylim(0, 1)
    ax.grid(color="#333333", linewidth=0.8)
    ax.spines["polar"].set_color("#444444")

                              
    ref = [1.0] * N + [1.0]
    ax.fill(angles, ref, color="#1a1a2e", alpha=0.3)
    ax.plot(angles, ref, color="#333333", linewidth=1, linestyle="--")

                  
    color_main = "#4FC3F7"
    ax.fill(angles, values_norm, color=color_main, alpha=0.25)
    ax.plot(angles, values_norm, color=color_main, linewidth=2.5)
    ax.scatter(angles[:-1], values_norm[:-1], color=color_main, s=80, zorder=5)

                      
    for angle, val_norm, val, max_v in zip(angles[:-1], values_norm[:-1], values, maxes):
        ax.annotate(f"{val:.0f}/{max_v}",
                    xy=(angle, val_norm),
                    xytext=(angle, val_norm + 0.08),
                    color="#FFD54F", fontsize=8, ha="center", fontweight="bold")

    total = score_result.get("total_score", 0)
    grade = score_result.get("grade", "")
    ax.set_title(f"Radar Scor Somn\n{total}/100 – {grade}",
                 color="white", fontsize=13, fontweight="bold", pad=20)

    out_path = os.path.join(OUTPUT_DIR, f"radar_{session_id}.png")
    plt.savefig(out_path, dpi=150, bbox_inches="tight", facecolor="#0D1117")
    plt.close()
    print(f"[RADAR] Salvat: {out_path}")


                                                                 
                                           
                                                                 

def compute_hrv_spectral(chunk: pd.DataFrame, t_start=None, t_end=None,
                          ppg_50hz_df: pd.DataFrame = None) -> dict:
    """
    Calculeaza HRV spectral (LF, HF, LF/HF) dintr-o fereastra.
    Foloseste PPG 50Hz daca e disponibil, altfel 10Hz din raw_data.
    """
    feats = {"hrv_lf": np.nan, "hrv_hf": np.nan,
             "hrv_lf_hf": np.nan, "hrv_sdnn": np.nan, "hrv_pnn50": np.nan}

                                                                  
    ir, fs = None, FS_IMU

    if (ppg_50hz_df is not None and not ppg_50hz_df.empty
            and t_start is not None and t_end is not None):
        ppg_chunk = ppg_50hz_df[
            (ppg_50hz_df["pc_timestamp"] >= t_start) &
            (ppg_50hz_df["pc_timestamp"] <  t_end)
        ]
        if len(ppg_chunk) >= 50:
            ir = ppg_chunk["ir"].values.astype(float)
            fs = FS_PPG        

    if ir is None:
        ir = chunk["ir"].dropna().values.astype(float)
        fs = FS_IMU        

                                                                  
    min_samples = fs * 10                    
    if len(ir) < min_samples:
        return feats

                                                                     
                                                             
    invalid_mask = (ir == 0) | (ir >= 262143)
    if invalid_mask.mean() > 0.7:                                          
        return feats

                                                               
    ir_series = pd.Series(ir.copy().astype(float))
    ir_series[invalid_mask] = np.nan
    ir_series = ir_series.interpolate(method='linear', limit=10)
    ir_series = ir_series.dropna()
    ir = ir_series.values

    if len(ir) < min_samples:
        return feats

                                                                   
    ir_norm = ir - np.mean(ir)
    try:
        ir_filt = bandpass_filter(ir_norm, lowcut=0.5, highcut=min(3.5, fs/2 - 0.1), fs=fs)
    except Exception:
        ir_filt = ir_norm

                                                                   
    min_dist = max(int(fs * 0.4), 1)
    prom_thresh = max(np.std(ir_filt) * 0.2, 1.0)
    peaks, _ = signal.find_peaks(ir_filt, distance=min_dist, prominence=prom_thresh)

    if len(peaks) < 4:
        return feats

                                                                   
    rr = np.diff(peaks) / fs
    rr = rr[(rr > 0.3) & (rr < 2.0)]
    if len(rr) < 4:
        return feats

    feats["hrv_sdnn"] = float(np.std(rr) * 1000)
    diffs = np.abs(np.diff(rr)) * 1000
    feats["hrv_pnn50"] = float(np.mean(diffs > 50) * 100)

                                                                   
    fs_interp = 4.0
    t_rr = np.cumsum(rr)
    t_uniform = np.arange(t_rr[0], t_rr[-1], 1.0 / fs_interp)
    if len(t_uniform) < 8:
        return feats

    rr_interp = np.interp(t_uniform, t_rr, rr)
    n = len(rr_interp)
    rr_win = (rr_interp - np.mean(rr_interp)) * np.hanning(n)
    fft_vals = np.abs(fft(rr_win)[:n // 2]) ** 2
    freqs    = fftfreq(n, 1.0 / fs_interp)[:n // 2]

    lf_mask = (freqs >= 0.04) & (freqs < 0.15)
    hf_mask = (freqs >= 0.15) & (freqs < 0.40)

    lf_power = float(np.trapz(fft_vals[lf_mask], freqs[lf_mask])) if np.any(lf_mask) else 0.0
    hf_power = float(np.trapz(fft_vals[hf_mask], freqs[hf_mask])) if np.any(hf_mask) else 0.0

    feats["hrv_lf"] = lf_power
    feats["hrv_hf"] = hf_power
    feats["hrv_lf_hf"] = float(lf_power / hf_power) if hf_power > 1e-12 else np.nan

    return feats


def plot_hrv_spectral(df: pd.DataFrame, session_id: str):
    """Grafic HRV: BPM + RMSSD + etapa somn pe axa timp."""
    import matplotlib.dates as mdates
    STAGE_COLORS_L = {"Light Sleep":"#4FC3F7","Deep Sleep":"#1565C0",
                      "REM Sleep":"#AB47BC","Wake / Movement":"#EF5350"}
    fig, axes = plt.subplots(3, 1, figsize=(14, 10), sharex=True)
    fig.patch.set_facecolor("#0D1117")
    times = df["window_start"]

    ax1 = axes[0]
    ax1.set_facecolor("#0D1117")
    if "bpm_mean" in df.columns:
        bpm = df["bpm_mean"].copy().where(df["bpm_mean"] > 20, float("nan"))
        ax1.plot(times, bpm, color="#4FC3F7", linewidth=1.0, alpha=0.8)
        ax1.fill_between(times, bpm.fillna(0), alpha=0.15, color="#4FC3F7")
        ax1.axhline(60, color="#66BB6A", linewidth=1, linestyle="--", alpha=0.5, label="60 BPM")
        ax1.legend(facecolor="#1a1a2e", edgecolor="#333", labelcolor="white", fontsize=8)
    ax1.set_ylabel("BPM", color="gray", fontsize=9)
    ax1.set_title("HRV Analysis – Variabilitate Cardiacă pe Noapte", color="white", fontsize=11, fontweight="bold")
    ax1.tick_params(colors="gray"); ax1.spines[:].set_color("#333333")

    ax2 = axes[1]
    ax2.set_facecolor("#0D1117")
    if "hrv_simple" in df.columns:
        hrv = df["hrv_simple"].copy().replace(0, float("nan")).clip(upper=300)
        ax2.plot(times, hrv, color="#AB47BC", linewidth=1.2, alpha=0.9)
        ax2.fill_between(times, hrv.fillna(0), alpha=0.2, color="#AB47BC")
        ymax = max(hrv.max() if hrv.notna().any() else 200, 100)
        ax2.axhspan(0, 20, alpha=0.07, color="#EF5350")
        ax2.axhspan(20, 80, alpha=0.07, color="#66BB6A")
        ax2.axhspan(80, ymax, alpha=0.07, color="#4FC3F7")
        import matplotlib.patches as mp
        ax2.legend(handles=[
            mp.Patch(color="#EF5350", alpha=0.5, label="HRV scazut (<20ms)"),
            mp.Patch(color="#66BB6A", alpha=0.5, label="HRV normal (20-80ms)"),
            mp.Patch(color="#4FC3F7", alpha=0.5, label="HRV ridicat (>80ms)"),
        ], facecolor="#1a1a2e", edgecolor="#333", labelcolor="white", fontsize=8)
    ax2.set_ylabel("RMSSD (ms)", color="gray", fontsize=9)
    ax2.tick_params(colors="gray"); ax2.spines[:].set_color("#333333")

    ax3 = axes[2]
    ax3.set_facecolor("#0D1117")
    stage_order = ["Wake / Movement","Light Sleep","REM Sleep","Deep Sleep"]
    stage_y = {s: i for i, s in enumerate(stage_order)}
    if "sleep_stage" in df.columns:
        for i in range(len(df)-1):
            stage = df["sleep_stage"].iloc[i]
            ax3.fill_between([times.iloc[i], times.iloc[i+1]],
                             [stage_y.get(stage,1)]*2, 0,
                             color=STAGE_COLORS_L.get(stage,"#888"), alpha=0.5)
        ax3.set_yticks(range(len(stage_order)))
        ax3.set_yticklabels(stage_order, color="white", fontsize=8)
    ax3.set_ylabel("Etapa Somn", color="gray", fontsize=9)
    ax3.tick_params(colors="gray"); ax3.spines[:].set_color("#333333")
    ax3.xaxis.set_major_formatter(mdates.DateFormatter("%H:%M"))
    plt.setp(ax3.get_xticklabels(), color="gray", fontsize=8)

    fig.text(0.5, 0.01,
        "Nota: LF/HF spectral necesita PPG continuu. Dispozitivul transmite PPG burst-mode → RMSSD este metrica HRV primara valida.",
        ha="center", color="#888888", fontsize=8)
    plt.tight_layout(rect=[0,0.03,1,1])
    out_path = os.path.join(OUTPUT_DIR, f"hrv_spectral_{session_id}.png")
    plt.savefig(out_path, dpi=150, bbox_inches="tight", facecolor="#0D1117")
    plt.close()
    print(f"[HRV]  Salvat: {out_path}")


def plot_multi_session_trend(db_path: str):
    """
    Incarca toate scorurile JSON disponibile si
    afiseaza evolutia în timp a scorului si componentelor.
    """
    score_files = [f for f in os.listdir(OUTPUT_DIR)
                   if f.startswith("score_") and f.endswith(".json")]

    if len(score_files) < 2:
        print(f"[TREND] Prea putine sesiuni ({len(score_files)}). Necesari minim 2.")
        return

    records = []
    for f in sorted(score_files):
        session_id = f.replace("score_", "").replace(".json", "")
        with open(os.path.join(OUTPUT_DIR, f)) as fp:
            data = json.load(fp)

                                                           
        try:
            conn = sqlite3.connect(db_path)
            row = conn.execute(
                "SELECT MIN(pc_timestamp) FROM raw_data WHERE session_id=?",
                (session_id,)
            ).fetchone()
            conn.close()
            date_str = row[0][:10] if row and row[0] else session_id[:8]
        except Exception:
            date_str = session_id[:8]

        rec = {
            "session_id": session_id,
            "date": date_str,
            "total_score": data.get("total_score", np.nan),
            "duration_min": data.get("session_duration_min", np.nan),
        }
        for k, v in data.get("components", {}).items():
            rec[f"comp_{k}"] = v
        for k, v in data.get("stage_distribution_pct", {}).items():
            rec[f"stage_{k.replace(' ','_').replace('/','_')}"] = v
        records.append(rec)

    df = pd.DataFrame(records)
    n = len(df)

    fig = plt.figure(figsize=(16, 12))
    fig.patch.set_facecolor("#0D1117")
    gs = gridspec.GridSpec(3, 2, figure=fig, hspace=0.5, wspace=0.35)

    x = range(n)
    x_labels = [r["date"] for r in records]

                               
    ax1 = fig.add_subplot(gs[0, :])
    ax1.set_facecolor("#0D1117")

    scores = df["total_score"].values
    colors_score = ["#EF5350" if s < 55 else "#FFA726" if s < 70
                    else "#4FC3F7" if s < 85 else "#66BB6A" for s in scores]

    bars = ax1.bar(x, scores, color=colors_score, width=0.6, edgecolor="#333333")
    for bar, val in zip(bars, scores):
        ax1.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.5,
                 f"{val:.0f}", ha="center", va="bottom", color="white", fontsize=10,
                 fontweight="bold")

                 
    if n >= 2:
        z = np.polyfit(list(x), scores, 1)
        ax1.plot(list(x), np.poly1d(z)(list(x)), color="#FFD54F",
                 linewidth=2, linestyle="--", label="Trend")
        trend_dir = "↑ Imbunatatire" if z[0] > 0 else "↓ Deteriorare"
        ax1.legend([trend_dir], facecolor="#1a1a2e", edgecolor="#333",
                   labelcolor="#FFD54F", fontsize=10)

    ax1.set_xticks(list(x))
    ax1.set_xticklabels(x_labels, color="gray", fontsize=9, rotation=15)
    ax1.set_ylabel("Scor Calitate Somn", color="gray")
    ax1.set_ylim(0, 105)
    ax1.set_title("Evolutia Scorului de Somn per Sesiune", color="white",
                  fontsize=12, fontweight="bold")
    ax1.axhline(85, color="#66BB6A", linewidth=1, linestyle=":", alpha=0.5)
    ax1.axhline(70, color="#4FC3F7", linewidth=1, linestyle=":", alpha=0.5)
    ax1.axhline(55, color="#FFA726", linewidth=1, linestyle=":", alpha=0.5)
    ax1.tick_params(colors="gray")
    ax1.spines[:].set_color("#333333")

                                 
    ax2 = fig.add_subplot(gs[1, 0])
    ax2.set_facecolor("#0D1117")
    comp_cols = [c for c in df.columns if c.startswith("comp_")]
    comp_colors = ["#4FC3F7","#AB47BC","#66BB6A","#FFA726","#EF5350","#78909C"]

    bottom = np.zeros(n)
    for i, col in enumerate(comp_cols):
        vals = df[col].fillna(0).values
        ax2.bar(x, vals, bottom=bottom, color=comp_colors[i % len(comp_colors)],
                label=col.replace("comp_","").replace("_"," ").title(),
                width=0.6, edgecolor="#222")
        bottom += vals

    ax2.set_xticks(list(x))
    ax2.set_xticklabels(x_labels, color="gray", fontsize=8, rotation=15)
    ax2.set_title("Componente Scor per Sesiune", color="white", fontsize=10)
    ax2.legend(facecolor="#1a1a2e", edgecolor="#333", labelcolor="white",
               fontsize=7, loc="upper right")
    ax2.tick_params(colors="gray")
    ax2.spines[:].set_color("#333333")

                                      
    ax3 = fig.add_subplot(gs[1, 1])
    ax3.set_facecolor("#0D1117")
    stage_map = {
        "stage_Deep_Sleep": ("#1565C0", "Deep Sleep"),
        "stage_Light_Sleep": ("#4FC3F7", "Light Sleep"),
        "stage_REM_Sleep": ("#AB47BC", "REM Sleep"),
        "stage_Wake___Movement": ("#EF5350", "Wake"),
    }
    for col, (color, label) in stage_map.items():
        if col in df.columns:
            ax3.plot(list(x), df[col].fillna(0).values, color=color,
                     linewidth=2, marker="o", markersize=5, label=label)

    ax3.set_xticks(list(x))
    ax3.set_xticklabels(x_labels, color="gray", fontsize=8, rotation=15)
    ax3.set_ylabel("% din sesiune", color="gray", fontsize=9)
    ax3.set_title("Distributie Etape Somn per Sesiune", color="white", fontsize=10)
    ax3.legend(facecolor="#1a1a2e", edgecolor="#333", labelcolor="white", fontsize=8)
    ax3.tick_params(colors="gray")
    ax3.spines[:].set_color("#333333")

                             
    ax4 = fig.add_subplot(gs[2, 0])
    ax4.set_facecolor("#0D1117")
    durations = df["duration_min"].fillna(0).values
    ax4.bar(x, durations, color="#78909C", width=0.6, edgecolor="#333")
    ax4.axhline(480, color="#66BB6A", linewidth=1, linestyle="--",
                label="8 ore recomandate")
    for i, (bar, val) in enumerate(zip(ax4.patches, durations)):
        ax4.text(i, val + 2, f"{val:.0f}m", ha="center", color="white", fontsize=8)
    ax4.set_xticks(list(x))
    ax4.set_xticklabels(x_labels, color="gray", fontsize=8, rotation=15)
    ax4.set_ylabel("Minute", color="gray", fontsize=9)
    ax4.set_title("Durata Sesiuni", color="white", fontsize=10)
    ax4.legend(facecolor="#1a1a2e", edgecolor="#333", labelcolor="white", fontsize=8)
    ax4.tick_params(colors="gray")
    ax4.spines[:].set_color("#333333")

                                 
    ax5 = fig.add_subplot(gs[2, 1])
    ax5.set_facecolor("#0D1117")
    ax5.axis("off")

    stats_text = [
        f"REZUMAT MULTI-SESIUNE",
        f"{'─'*30}",
        f"Nr. sesiuni:      {n}",
        f"Scor mediu:       {df['total_score'].mean():.1f}/100",
        f"Scor maxim:       {df['total_score'].max():.1f}/100",
        f"Scor minim:       {df['total_score'].min():.1f}/100",
        f"Deviatie std:     {df['total_score'].std():.1f}",
        f"{'─'*30}",
    ]

    if n >= 2:
        z = np.polyfit(list(range(n)), df["total_score"].values, 1)
        trend_val = z[0]
        trend_str = f"+{trend_val:.1f}" if trend_val > 0 else f"{trend_val:.1f}"
        stats_text.append(f"Trend:            {trend_str} pt/noapte")
        stats_text.append(f"Directie:         {'Imbunatatire ↑' if trend_val > 0 else 'Deteriorare ↓'}")

    for i, line in enumerate(stats_text):
        color = "#FFD54F" if i == 0 else "white" if "─" not in line else "#444444"
        ax5.text(0.05, 0.95 - i * 0.085, line, transform=ax5.transAxes,
                 color=color, fontsize=10,
                 fontfamily="monospace" if "─" not in line else "monospace")

    plt.suptitle("Analiza Multi-Sesiune – Evolutia Calitatii Somnului",
                 color="white", fontsize=13, fontweight="bold", y=1.01)

    out_path = os.path.join(OUTPUT_DIR, "trend_multi_session.png")
    plt.savefig(out_path, dpi=150, bbox_inches="tight", facecolor="#0D1117")
    plt.close()
    print(f"[TREND] Salvat: {out_path}")


                                                                 
                                                 
                                                                 

def run_random_forest(df: pd.DataFrame, X_scaled: np.ndarray,
                      feat_cols: list, session_id: str):
    """
    Antreneaza Random Forest pe labelele K-Means.
    Compara cu KNN prin cross-validation si feature importance.

    IMPORTANT: foloseste cross_val_predict pentru predictii HONEST
    (fiecare fereastra e prezisa de modelul ANTRENAT fara ea), nu
    predict pe setul de antrenare (care da 100% accuracy fictiva).
    """
    from sklearn.model_selection import cross_val_predict

    y = df["sleep_stage"].values
    le = LabelEncoder()
    y_enc = le.fit_transform(y)

    if len(set(y_enc)) < 2:
        print("[RF] Prea putine clase pentru comparatie!")
        return None, None

                         
    rf = RandomForestClassifier(
        n_estimators=100, random_state=42,
        max_depth=8, min_samples_leaf=2,
        class_weight="balanced"
    )

               
    k = min(5, len(df) - 1)
    knn = KNeighborsClassifier(n_neighbors=k, metric="euclidean", weights="distance")

                      
    n_splits = min(5, len(df) // max(len(set(y_enc)), 1))
    results = {}

    if n_splits >= 2:
        cv = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=42)
        rf_scores  = cross_val_score(rf,  X_scaled, y_enc, cv=cv, scoring="accuracy")
        knn_scores = cross_val_score(knn, X_scaled, y_enc, cv=cv, scoring="accuracy")
        results["rf_cv_mean"]  = rf_scores.mean()
        results["rf_cv_std"]   = rf_scores.std()
        results["knn_cv_mean"] = knn_scores.mean()
        results["knn_cv_std"]  = knn_scores.std()
        print(f"[RF]  Random Forest CV: {rf_scores.mean()*100:.1f}% ± {rf_scores.std()*100:.1f}%")
        print(f"[KNN] KNN CV:           {knn_scores.mean()*100:.1f}% ± {knn_scores.std()*100:.1f}%")

                                                                 
                                                                           
        print("[RF]  Calculez predictii out-of-fold (honest, nu train+predict)...")
        rf_pred_enc  = cross_val_predict(rf,  X_scaled, y_enc, cv=cv)
        knn_pred_enc = cross_val_predict(knn, X_scaled, y_enc, cv=cv)
        rf_pred  = le.inverse_transform(rf_pred_enc)
        knn_pred = le.inverse_transform(knn_pred_enc)

                               
        rf_oof_acc  = (rf_pred  == y).mean()
        knn_oof_acc = (knn_pred == y).mean()
        print(f"[RF]  Out-of-fold accuracy  RF: {rf_oof_acc*100:.1f}%")
        print(f"[KNN] Out-of-fold accuracy KNN: {knn_oof_acc*100:.1f}%")
    else:
        print("[RF] Prea putine date pentru cross-validation, antrenez pe tot setul")
        rf.fit(X_scaled, y_enc)
        knn.fit(X_scaled, y_enc)
        rf_pred  = le.inverse_transform(rf.predict(X_scaled))
        knn_pred = le.inverse_transform(knn.predict(X_scaled))

                                                                 
    rf.fit(X_scaled, y_enc)

    df = df.copy()
    df["rf_stage"]  = rf_pred
    df["knn_stage"] = knn_pred

                           
    feat_importance = pd.Series(rf.feature_importances_, index=feat_cols)
    feat_importance = feat_importance.sort_values(ascending=False)

                              
    plot_rf_vs_knn(df, feat_importance, results, feat_cols, session_id, le, X_scaled, y_enc)

    return rf, feat_importance


def plot_rf_vs_knn(df, feat_importance, cv_results, feat_cols,
                   session_id, le, X_scaled, y_enc):
    """Grafice complete RF vs KNN."""

    fig = plt.figure(figsize=(18, 14))
    fig.patch.set_facecolor("#0D1117")
    gs = gridspec.GridSpec(3, 3, figure=fig, hspace=0.5, wspace=0.4)

    classes = list(df["sleep_stage"].unique())
    stage_colors_list = [STAGE_COLORS.get(c, "#888") for c in classes]

                                             
    ax1 = fig.add_subplot(gs[0, :2])
    ax1.set_facecolor("#0D1117")
    top_n = min(10, len(feat_importance))
    top_feats = feat_importance.head(top_n)
    colors_fi = plt.cm.RdYlGn(np.linspace(0.3, 0.9, top_n))
    bars = ax1.barh(range(top_n), top_feats.values[::-1],
                    color=colors_fi, edgecolor="#333")
    ax1.set_yticks(range(top_n))
    ax1.set_yticklabels(top_feats.index[::-1], color="white", fontsize=9)
    ax1.set_xlabel("Importanta (Gini)", color="gray", fontsize=9)
    ax1.set_title("Top Features – Random Forest", color="white", fontsize=11,
                  fontweight="bold")
    ax1.tick_params(colors="gray")
    ax1.spines[:].set_color("#333333")
    for bar, val in zip(bars, top_feats.values[::-1]):
        ax1.text(val + 0.002, bar.get_y() + bar.get_height()/2,
                 f"{val:.3f}", va="center", color="white", fontsize=8)

                                      
    ax2 = fig.add_subplot(gs[0, 2])
    ax2.set_facecolor("#0D1117")
    if cv_results:
        algos = ["Random\nForest", "KNN"]
        means = [cv_results.get("rf_cv_mean", 0) * 100,
                 cv_results.get("knn_cv_mean", 0) * 100]
        stds  = [cv_results.get("rf_cv_std",  0) * 100,
                 cv_results.get("knn_cv_std",  0) * 100]
        colors_cv = ["#66BB6A", "#4FC3F7"]
        bars_cv = ax2.bar(algos, means, color=colors_cv, width=0.5,
                          edgecolor="#333", yerr=stds, capsize=8,
                          error_kw={"ecolor": "white", "linewidth": 2})
        for bar, val in zip(bars_cv, means):
            ax2.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 1,
                     f"{val:.1f}%", ha="center", color="white",
                     fontsize=11, fontweight="bold")
        ax2.set_ylim(0, 115)
        ax2.set_ylabel("Acuratete (%)", color="gray", fontsize=9)
        ax2.set_title("Acuratete CV\n(5-fold)", color="white", fontsize=10)
    else:
        ax2.text(0.5, 0.5, "Date insuficiente\npentru CV",
                 ha="center", va="center", color="gray", transform=ax2.transAxes)
        ax2.set_title("Acuratete CV", color="white", fontsize=10)
    ax2.tick_params(colors="gray")
    ax2.spines[:].set_color("#333333")

                                  
    ax3 = fig.add_subplot(gs[1, 0])
    ax3.set_facecolor("#0D1117")
    _plot_confusion_matrix(ax3, df["sleep_stage"].values,
                           df["rf_stage"].values, "Matrice Confuzie\nRandom Forest")

                                   
    ax4 = fig.add_subplot(gs[1, 1])
    ax4.set_facecolor("#0D1117")
    _plot_confusion_matrix(ax4, df["sleep_stage"].values,
                           df["knn_stage"].values, "Matrice Confuzie\nKNN")

                                            
    ax5 = fig.add_subplot(gs[1, 2])
    ax5.set_facecolor("#0D1117")
    agree = df["rf_stage"] == df["knn_stage"]
    agree_pct = agree.mean() * 100
    ax5.pie([agree_pct, 100 - agree_pct],
            labels=[f"Acord\n{agree_pct:.0f}%", f"Dezacord\n{100-agree_pct:.0f}%"],
            colors=["#66BB6A", "#EF5350"],
            textprops={"color": "white", "fontsize": 10},
            startangle=90)
    ax5.set_title("Acord RF vs KNN\nper fereastra 30s", color="white", fontsize=10)

                                             
    ax6 = fig.add_subplot(gs[2, :])
    ax6.set_facecolor("#0D1117")
    stage_order = ["Wake / Movement", "Light Sleep", "REM Sleep", "Deep Sleep"]
    stage_y = {s: i for i, s in enumerate(stage_order)}
    times = df["window_start"]

    rf_y  = df["rf_stage"].map(lambda s: stage_y.get(s, 1))
    knn_y = df["knn_stage"].map(lambda s: stage_y.get(s, 1))
    km_y  = df["sleep_stage"].map(lambda s: stage_y.get(s, 1))

    ax6.step(times, km_y,  color="#FFD54F", linewidth=1.5, where="post",
             label="K-Means (referinta)", alpha=0.8)
    ax6.step(times, rf_y,  color="#66BB6A", linewidth=1.2, where="post",
             label="Random Forest", linestyle="--", alpha=0.9)
    ax6.step(times, knn_y, color="#4FC3F7", linewidth=1.0, where="post",
             label="KNN", linestyle=":", alpha=0.9)

    ax6.set_yticks(range(len(stage_order)))
    ax6.set_yticklabels(stage_order, color="white", fontsize=9)
    ax6.legend(facecolor="#1a1a2e", edgecolor="#333", labelcolor="white", fontsize=9)
    ax6.set_title("Comparatie Clasificare: K-Means vs RF vs KNN in Timp",
                  color="white", fontsize=10, fontweight="bold")
    ax6.tick_params(colors="gray")
    ax6.spines[:].set_color("#333333")

    import matplotlib.dates as mdates
    ax6.xaxis.set_major_formatter(mdates.DateFormatter("%H:%M"))
    plt.setp(ax6.get_xticklabels(), color="gray", fontsize=8)

    plt.suptitle(f"Comparatie Algoritmi: Random Forest vs KNN – {session_id}",
                 color="white", fontsize=13, fontweight="bold", y=1.01)

    out_path = os.path.join(OUTPUT_DIR, f"rf_vs_knn_{session_id}.png")
    plt.savefig(out_path, dpi=150, bbox_inches="tight", facecolor="#0D1117")
    plt.close()
    print(f"[RF]   Salvat: {out_path}")


def _plot_confusion_matrix(ax, y_true, y_pred, title):
    """Helper pentru matrice de confuzie."""
    classes = sorted(set(list(y_true) + list(y_pred)))
    cm = confusion_matrix(y_true, y_pred, labels=classes)
    cm_norm = cm.astype(float) / (cm.sum(axis=1, keepdims=True) + 1e-9)

    im = ax.imshow(cm_norm, cmap="Blues", vmin=0, vmax=1)
    ax.set_xticks(range(len(classes)))
    ax.set_yticks(range(len(classes)))
    short = [c.split()[0] for c in classes]
    ax.set_xticklabels(short, color="white", fontsize=7, rotation=30)
    ax.set_yticklabels(short, color="white", fontsize=7)
    ax.set_xlabel("Prezis", color="gray", fontsize=8)
    ax.set_ylabel("Real", color="gray", fontsize=8)
    ax.set_title(title, color="white", fontsize=9)

    for i in range(len(classes)):
        for j in range(len(classes)):
            val = cm_norm[i, j]
            ax.text(j, i, f"{val:.0%}", ha="center", va="center",
                    color="white" if val < 0.6 else "black", fontsize=8)


                                                                 
                                                               
                                                                 

def plot_correlation_heatmap(db_path: str):
    """
    Heatmap complet cu corelatiile Pearson intre
    toate features obiective si toate raspunsurile subiective.
    """
                                                
    feat_files = [f for f in os.listdir(OUTPUT_DIR)
                  if f.startswith("features_") and f.endswith(".csv")]
    if not feat_files:
        print("[HEATMAP] Nu exista fisiere features CSV!")
        return

    all_feats = []
    for f in feat_files:
        session_id = f.replace("features_", "").replace(".csv", "")
        df = pd.read_csv(os.path.join(OUTPUT_DIR, f))
                           
        numeric_cols = df.select_dtypes(include=np.number).columns
        means = df[numeric_cols].mean()
        means["session_id"] = session_id
        all_feats.append(means)

    obj_df = pd.DataFrame(all_feats)

                        
    conn = sqlite3.connect(db_path)
    try:
        q_df = pd.read_sql_query("SELECT * FROM questionnaire", conn)
    except Exception:
        q_df = pd.DataFrame()
    conn.close()

    if q_df.empty:
        print("[HEATMAP] Nu exista date din chestionar!")
        return

    merged = pd.merge(obj_df, q_df, on="session_id", how="inner")
    if len(merged) < 2:
        print(f"[HEATMAP] Prea putine sesiuni comune ({len(merged)}). Necesari minim 2.")
        return

                                   
    obj_cols = [c for c in FEATURE_COLS if c in merged.columns]

                           
    merged["q_quality"]   = pd.to_numeric(merged.get("sleep_quality", np.nan), errors="coerce")
    merged["q_refreshed"] = pd.to_numeric(merged.get("refreshed_feeling", np.nan), errors="coerce")
    merged["q_stress"]    = pd.to_numeric(merged.get("stress_level", np.nan), errors="coerce")
    merged["q_wakeups"]   = merged.get("wakeups_count", "0").map(
        {"0": 0, "1": 1, "2": 2, "3": 3, "More than 3": 4})
    merged["q_movement"]  = merged.get("movement_felt", "Not at all").map(
        {"Not at all": 0, "A little": 1, "Moderately": 2, "A lot": 3})
    merged["q_snore"]     = merged.get("snored", "No").map(
        {"No": 0, "Yes, mildly": 1, "Yes, frequently": 2, "I do not know": 0})

    subj_cols = ["q_quality", "q_refreshed", "q_stress", "q_wakeups",
                 "q_movement", "q_snore"]
    subj_labels = ["Calitate\nSomn", "Senzatie\nOdihnit", "Stres\nPre-somn",
                   "Nr.\nTreziri", "Miscare\nPerceputa", "Sforait\nRaportat"]

                              
    corr_matrix = np.zeros((len(obj_cols), len(subj_cols)))
    for i, oc in enumerate(obj_cols):
        for j, sc in enumerate(subj_cols):
            x = merged[oc].dropna()
            y = merged[sc].dropna()
            common = x.index.intersection(y.index)
            if len(common) >= 2:
                corr_matrix[i, j] = x[common].corr(y[common])
            else:
                corr_matrix[i, j] = np.nan

          
    fig, ax = plt.subplots(figsize=(12, max(8, len(obj_cols) * 0.5)))
    fig.patch.set_facecolor("#0D1117")
    ax.set_facecolor("#0D1117")

                                     
    cmap = plt.cm.RdBu_r
    im = ax.imshow(corr_matrix, cmap=cmap, vmin=-1, vmax=1, aspect="auto")

              
    cbar = plt.colorbar(im, ax=ax, fraction=0.03, pad=0.04)
    cbar.ax.yaxis.set_tick_params(color="white")
    cbar.set_label("Corelatie Pearson (r)", color="white", fontsize=10)
    plt.setp(cbar.ax.yaxis.get_ticklabels(), color="white")

              
    ax.set_xticks(range(len(subj_cols)))
    ax.set_xticklabels(subj_labels, color="white", fontsize=9)
    ax.set_yticks(range(len(obj_cols)))
    ax.set_yticklabels(obj_cols, color="white", fontsize=8)

                      
    for i in range(len(obj_cols)):
        for j in range(len(subj_cols)):
            val = corr_matrix[i, j]
            if not np.isnan(val):
                text_color = "white" if abs(val) < 0.6 else "black"
                ax.text(j, i, f"{val:.2f}", ha="center", va="center",
                        color=text_color, fontsize=7, fontweight="bold")
            else:
                ax.text(j, i, "N/A", ha="center", va="center",
                        color="#555555", fontsize=6)

    ax.set_title("Heatmap Corelatii: Features Obiective (Senzori) vs Subiective (Chestionar)",
                 color="white", fontsize=11, fontweight="bold", pad=15)
    ax.tick_params(top=True, bottom=False, labeltop=True, labelbottom=False)
    plt.setp(ax.get_xticklabels(), rotation=0)

                          
    legend_text = "r > +0.7: Corelatie pozitiva puternica  |  r < -0.7: Corelatie negativa puternica  |  |r| < 0.3: Slaba"
    fig.text(0.5, -0.01, legend_text, ha="center", color="gray", fontsize=8)

    plt.tight_layout()
    out_path = os.path.join(OUTPUT_DIR, "correlation_heatmap.png")
    plt.savefig(out_path, dpi=150, bbox_inches="tight", facecolor="#0D1117")
    plt.close()
    print(f"[HEATMAP] Salvat: {out_path}")


                                                                 
                           
                                                                 

def run_advanced_analysis(session_id: str = None):
    """Ruleaza toate analizele avansate pentru o sesiune."""
    print(f"\n{'='*60}")
    print(f"  ANALIZA AVANSATA")
    print(f"  Sesiune: {session_id or 'TOATE'}")
    print(f"{'='*60}\n")

                  
    raw_df = load_raw_data(DB_PATH, session_id)
    mic_df = load_mic_data(DB_PATH, session_id)

    if raw_df.empty:
        print("EROARE: Nu exista date!")
        return

    if session_id is None:
        conn = sqlite3.connect(DB_PATH)
        sessions = pd.read_sql_query(
            "SELECT DISTINCT session_id FROM raw_data", conn
        )["session_id"].tolist()
        conn.close()
        if not sessions:
            return
        session_id = sessions[0]
        raw_df = load_raw_data(DB_PATH, session_id)
        mic_df = load_mic_data(DB_PATH, session_id)

                                 
    windows = split_windows(raw_df, WINDOW_SEC)
    if not windows:
        print("EROARE: Ferestre insuficiente!")
        return

                                          
    import sleep_pipeline as _sp
    ppg_blocks = load_ppg_data(DB_PATH, session_id)
    if not ppg_blocks.empty:
        _sp._ppg_50hz_df = expand_ppg_blocks(ppg_blocks)
    else:
        _sp._ppg_50hz_df = pd.DataFrame()
    print(f"[PPG]  50Hz: {len(_sp._ppg_50hz_df)} sample-uri pentru HRV spectral")

    features_df = extract_all_features(windows, mic_df)

                                  
    print("[HRV] Calculez features HRV spectral...")
    ppg50 = _sp._ppg_50hz_df
    hrv_records = []
    n_valid_hrv = 0
    for t_start, chunk in windows:
        t_end_w = t_start + pd.Timedelta(seconds=WINDOW_SEC)
        hrv_feats = compute_hrv_spectral(chunk, t_start=t_start, t_end=t_end_w,
                                          ppg_50hz_df=ppg50)
        if not np.isnan(hrv_feats.get("hrv_lf_hf", np.nan)):
            n_valid_hrv += 1
        hrv_feats["window_start"] = t_start
        hrv_records.append(hrv_feats)
    print(f"[HRV]  {n_valid_hrv}/{len(windows)} ferestre cu HRV spectral valid")
    hrv_df = pd.DataFrame(hrv_records)
    features_df = pd.merge(features_df, hrv_df, on="window_start", how="left")

                  
    df_clean, X_scaled, scaler, feat_cols = preprocess_features(features_df)

             
    df_clean, km_model = run_kmeans(df_clean, X_scaled, feat_cols)

                                                                        
                                                                      
    score_json_path = os.path.join(OUTPUT_DIR, f"score_{session_id}.json")
    score_result = None
    if os.path.exists(score_json_path):
        try:
            with open(score_json_path, "r") as f:
                score_result = json.load(f)
            print(f"[SCORE] Incarcat scor existent din {score_json_path}: {score_result.get('total_score')}/100")
        except Exception as e:
            print(f"[SCORE] Eroare la citire JSON: {e}")
            score_result = None

                                                    
    if score_result is None:
        print("[SCORE] Recalculez scorul...")
        score_result = compute_sleep_score(df_clean)

                          
    print("\n[1/5] Generez Radar Chart...")
    plot_radar_chart(score_result, session_id)

                           
    print("[2/5] Generez grafic HRV Spectral...")
    plot_hrv_spectral(df_clean, session_id)

                                  
    print("[3/5] Generez Trend Multi-Sesiune...")
                                                                   
    if not os.path.exists(score_json_path):
        with open(score_json_path, "w") as f:
            json.dump(score_result, f, indent=2, default=str)
    plot_multi_session_trend(DB_PATH)

                                   
    print("[4/5] Compara Random Forest vs KNN...")
    run_random_forest(df_clean, X_scaled, feat_cols, session_id)

                                
    print("[5/5] Generez Heatmap Corelatii...")
    plot_correlation_heatmap(DB_PATH)

    print(f"\n✅  Analiza avansata completa! Fisierele sunt in: ./{OUTPUT_DIR}/")
    print("\nFisiere generate:")
    new_files = [
        f"radar_{session_id}.png",
        f"hrv_spectral_{session_id}.png",
        "trend_multi_session.png",
        f"rf_vs_knn_{session_id}.png",
        "correlation_heatmap.png",
    ]
    for f in new_files:
        path = os.path.join(OUTPUT_DIR, f)
        exists = "✅" if os.path.exists(path) else "❌"
        print(f"  {exists} {f}")


                                                                 
              
                                                                 

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("""
Utilizare:
  python3 advanced_analysis.py <session_id>    # analiza completa
  python3 advanced_analysis.py trend           # doar trend multi-sesiune
  python3 advanced_analysis.py heatmap         # doar heatmap corelatii
        """)
        sys.exit(0)

    cmd = sys.argv[1]

    if cmd == "trend":
        plot_multi_session_trend(DB_PATH)
    elif cmd == "heatmap":
        plot_correlation_heatmap(DB_PATH)
    else:
        run_advanced_analysis(cmd)
